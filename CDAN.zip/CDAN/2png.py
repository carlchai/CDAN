from PIL import Image
import os

# 设置输入文件夹路径和目标格式
input_folder = './dataset/VL-CMU-CD/train/666/RGB'
target_format = 'png'

# 循环遍历输入文件夹中的所有文件
for filename in os.listdir(input_folder):
    # 检查文件是否为jpg格式
    if filename.endswith('.jpg'):
        # 组合新的文件名和路径
        img_path_jpg = os.path.join(input_folder, filename)
        img_path_png = os.path.splitext(img_path_jpg)[0] + '.' + target_format

        # 读取JPG格式图片并保存为PNG格式
        with Image.open(img_path_jpg) as img:
            img.save(img_path_png)

        # 删除原始JPG格式图片
        os.remove(img_path_jpg)

