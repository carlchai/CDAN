import os.path
from collections import OrderedDict

import torch
from PIL import Image

import utils

def save_img(model_path,save_imgs_dir,data_loader,device):
    model = torch.load(model_path)
    model.eval()
    metric_logger = utils.metric_util.MetricLogger(delimiter="  ")
    with torch.no_grad():
        for image, target in metric_logger.log_every(data_loader, 100, header='Save:'):
            image, target = image.to(device), target.to(device)
            output = model(image)
            if isinstance(output, OrderedDict):
                output = output['out']
            mask_pred = torch.topk(output.data, 1, dim=1)[1][:, 0]
            mask_gt = (target > 0)[:, 0]
            precision, recall, accuracy, f1score = utils.metric_util.CD_metric_torch(mask_pred, mask_gt)
            assert len(precision) == 1, "save imgs needs batch_size=1"
            output_pil = data_loader.dataset.get_pil(image[0], mask_gt, mask_pred)
            output_pil.save(os.path.join(save_imgs_dir, "{}_{}.png".format(utils.metric_util.get_rank(), metric_logger.F1score.count)))




if __name__ =="__main__":
    model_path = "output_vlcmucd"
    save_imgs_dir = "output_img1"


