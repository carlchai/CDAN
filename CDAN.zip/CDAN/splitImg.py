import os
from PIL import Image

path_img = './VLCMUCD/output_img_AF'  # 源图片存储路径 文件夹
img_dir = os.listdir(path_img)  # 返回指定目录下的文件和文件夹的名称列表
print(img_dir)
print(len(img_dir))
for i in range(len(img_dir)):
    id = img_dir[i].split('.')[0]  # 分割图片名作为id
    img = Image.open(path_img + '/' + img_dir[i])
    size_img = img.size
    weight = int(size_img[0] // 2)  # 分割后图片的宽度/2
    height = int(size_img[1] // 2)  # 分割后图片的高度/2

    box1 = (weight , height , weight *2, height * 2)#pred
    box2 = (0, height , weight , height * 2)#mask
    box3 = (0, 0 , weight , height)#t0
    box4 = (weight, 0 , weight*2 , height )#t1
    region = img.crop(box2)  # 起始XY结束XY
    region2 = img.crop(box1)  # 起始XY结束XY
    region3 = img.crop(box4)  # 起始XY结束XY
    region4 = img.crop(box3)  # 起始XY结束XY
    region.save('./output_img1/''{}.jpg'.format(id))  # 输出路径
    region2.save('./output_img2/''{}.jpg'.format(id))  # 输出路径
    region3.save('./output_img3/''{}.jpg'.format(id))  # 输出路径
    region4.save('./output_img4/''{}.jpg'.format(id))  # 输出路径
